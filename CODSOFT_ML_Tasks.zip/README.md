# CODSOFT Machine Learning Internship Tasks

This repository includes the following completed tasks for the CODSOFT ML Internship:

## ✅ Task 1: Movie Genre Classification
- TF-IDF for text vectorization
- Logistic Regression model

## ✅ Task 2: Credit Card Fraud Detection
- Random Forest Classifier

## ✅ Task 3: Customer Churn Prediction
- Logistic Regression model

> Each task includes a complete Python script for training and testing the respective models.

---

📌 Datasets used:
Please refer to the Kaggle links provided in the task document or use mock/sample datasets included in the code.